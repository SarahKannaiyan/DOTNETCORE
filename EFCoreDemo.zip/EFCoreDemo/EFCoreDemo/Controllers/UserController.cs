﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFCoreDemo.Models;
using Microsoft.AspNetCore.Mvc;

namespace EFCoreDemo.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserInfo model)
        {
            //Custom validation
            //if (model.Email.EndsWith("gmail.com"))
            //{
            //    ModelState.AddModelError("Email", "Email cannot be from a public domain");
            //}
            //TryValidateModel(model);

            if (ModelState.IsValid)
            {
                //Do some action
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError("", "User details validation failed");
                return View(model);
            }
        }

       // [AcceptVerbs("Get, Post")]
        public IActionResult VerifyUsername(string username)
        {
            var userlist = new[] { "SarahPraveenRaj", "Praveena", "Blessy", "Solomon" ,"Samuel"};
            if(userlist.Contains(username))
            {
               // return Json(false);
                return Json("username is already taken by somebody else");
            }
            else
            {
                //return Json(true);
                return Json("username is available");
            }
        }
       
    }
}