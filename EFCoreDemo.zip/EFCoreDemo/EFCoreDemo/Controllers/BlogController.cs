﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFCoreDemo.Models;
using EFCoreDemo.Services;
using Microsoft.AspNetCore.Mvc;

namespace EFCoreDemo.Controllers
{
    public class BlogController : Controller
    {

        private IBlogService blogService;

        public BlogController(IBlogService blogSvc)
        {
            this.blogService = blogSvc;
        }

        #region List blogs
        [HttpGet("", Name = "ListBlogs")]
        public IActionResult Index([FromServices] IBlogService svc)
        {
            //var model = this.blogService.GetBlogs();
            var model = svc.GetBlogs();
            return View(model);
        }
        #endregion


        [HttpGet("new", Name = "AddBlog")]
        public IActionResult Create()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost("new", Name = "AddBlog")]
        public IActionResult Create(Blog model)
        {
            if(ModelState.IsValid)
            {
                this.blogService.AddBlogAsync(model);
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Invalid blog data");
                return View();
            }            
        }

        #region Edit Blog

        [HttpGet("edit/{id:int?}", Name = "EditBlog")]
        public async Task<IActionResult> Edit([FromRoute] int? id, [FromServices] IBlogService svc)
        {
            if (id == null)
            {
                return NotFound();
            }
            var blog = await svc.GetBlogByIdAsync(id.Value);
            if (blog == null)
            {
                return NotFound();
            }
            else
            {
                return View(blog);
            }
        }
        #endregion

        #region Update Blog
        [HttpPost("edit/{id:int?}", Name = "UpdateBlog")]
        public async Task<IActionResult> Edit([FromRoute] int? id, [Bind("Id,Title,Content,Email,AddedDate")] Blog model)
        {
            if (ModelState.IsValid)
            {
                await this.blogService.UpdateBlogAsync(id.Value, model);
                return RedirectToAction("Index");
            }
            else
            {
                return View(model);
            }
        }
        #endregion

    }
}