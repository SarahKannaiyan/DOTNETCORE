﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using EFCoreDemo.CustomAttributes;
using Microsoft.AspNetCore.Mvc;

namespace EFCoreDemo.Models
{
    public class UserInfo:IValidatableObject
    {
        [Required(ErrorMessage="Username cannot be empty")]
        [MaxLength(40, ErrorMessage="Username can contain maximum 40 characters")]
        [Remote("VerifyUsername", "User", ErrorMessage="Username not available")]
        public string Username { get; set; }

        [DataType(DataType.Password)]
        [Required(ErrorMessage="Password cannt be empty")]
        [StringLength(20,MinimumLength=8, ErrorMessage="Password length must be between 8 and 20 chararcters")]
        public string Password { get; set; }

        [Compare(nameof(Password), ErrorMessage="Password mismatch")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage="Confirm password cannot be empty")]
        [Display(Name ="Confirm password")]
        public string ConfirmPassword { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage="Invalid email format")]
        [Required(ErrorMessage="Email is required")]
        //[CompanyEmail(ErrorMessage="gmail not accepted")]
        public string Email { get; set; }

        [Url(ErrorMessage="Invalid url format")]
        [Required(ErrorMessage ="Company website URL cannot be empty")]
        [Display(Name ="Company website")]
        public string CompanyUrl { get; set; }

        [Range(22,65,ErrorMessage="Age must be between 22 and 65")]
        [Required(ErrorMessage="Age cannot be empty")]
        public int Age { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage="Invalid phone number format")]       
        public string Telephone { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Email.EndsWith("gmail.com"))
            {
                yield return new ValidationResult("Email cannot be from public domain", new[] { "Email" });
            }

        }
    }
}
