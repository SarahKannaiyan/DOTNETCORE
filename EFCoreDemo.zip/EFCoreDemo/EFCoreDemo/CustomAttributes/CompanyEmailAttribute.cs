﻿using EFCoreDemo.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreDemo.CustomAttributes
{
    public class CompanyEmailAttribute:ValidationAttribute
    {    
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var message = string.IsNullOrEmpty(ErrorMessage) ? "Email cannot be from a public domain" : ErrorMessage;
            UserInfo userInfo = validationContext.ObjectInstance as UserInfo;

            if (userInfo.Email.EndsWith("gmail.com"))
            {
                return new ValidationResult(message);
            }
            else
            {
                return ValidationResult.Success;
            }
        }
    }
}
