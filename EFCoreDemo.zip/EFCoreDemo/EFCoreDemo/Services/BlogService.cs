﻿using EFCoreDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreDemo.Services
{
    public class BlogService:IBlogService
    {
        public async Task<Blog> AddBlogAsync(Blog blog)
        {
            using (BlogContext db = new BlogContext())
            {
                blog.AddedDate = DateTime.Now;
                db.Blogs.Add(blog);
                await db.SaveChangesAsync();
                return blog;
            }
        }

        public async Task<Blog> GetBlogByIdAsync(int id)
        {
            using (BlogContext db = new BlogContext())
            {
                //var blog = db.Blogs.SingleOrDefault(b => b.Id == id);
                var blog = await db.Blogs.FindAsync(id);
                return blog;
            }
        }
       

        public IEnumerable<Blog> GetBlogs()
        {
            using (BlogContext db = new BlogContext())
            {               
                return db.Blogs.ToList();
            }
        }

        public async Task<Blog> UpdateBlogAsync(int id, Blog blog)
        {
            using (BlogContext db = new BlogContext())
            {
                if(id != blog.Id)
                {
                    throw new Exception("Blog not found");
                }
                db.Update(blog);
                await db.SaveChangesAsync();
                return blog;
            }
        }
    }
}
