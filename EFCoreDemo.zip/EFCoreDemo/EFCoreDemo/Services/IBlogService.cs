﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFCoreDemo.Models;

namespace EFCoreDemo.Services
{
    public interface IBlogService
    {
        IEnumerable<Blog> GetBlogs();

        Task<Blog> GetBlogByIdAsync(int id);

        Task<Blog> AddBlogAsync(Blog blog);

        Task<Blog> UpdateBlogAsync(int id, Blog blog);

        
        
    }
}
