﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using JWTAuth.Models;
using Microsoft.AspNetCore.Authorization;

namespace JWTAuth.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BlogsController : Controller
    {
        private IEnumerable<Blogs> blogs = new List<Blogs>
        {
            new Blogs { Id =1, Title ="Blog 1", Content="Blog Content1", AddedBy="Sarah PraveenRaj",AddedDate=DateTime.Now },
             new Blogs { Id =1, Title ="Blog 2", Content="Blog Content2", AddedBy="Sarah PraveenRaj",AddedDate=DateTime.Now },
              new Blogs { Id =1, Title ="Blog 3", Content="Blog Content3", AddedBy="Sarah PraveenRaj",AddedDate=DateTime.Now },
        };

       
        [HttpGet("", Name = "ListBlogs")]
        public ActionResult<IEnumerable<Blogs>> GetBlogs()
        {
            return blogs.ToList();
        }
    }
}