﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using StateManagement_DEMO.Models;
using StateManagement_DEMO.Services;

namespace StateManagement_DEMO.Controllers
{
    public class HomeController : Controller
    {

        private DataService service;
        private IMemoryCache memoryCache;
        private IDistributedCache distributedCache;

        public HomeController(DataService srv, IMemoryCache memoryCache,IDistributedCache distributedCache)
        {
            this.service = srv;
            //this.memoryCache = memoryCache;
            this.distributedCache = distributedCache;
        }
        public IActionResult Index()
        {
            var usertype = HttpContext.Items["usertype"].ToString();
            return View();
        }
        [HttpPost]
        public IActionResult Index(string firstname)
        {
            //Cookies
            //Response.Cookies.Append("myname", firstname, new CookieOptions
            //{
            //    MaxAge = TimeSpan.FromMinutes(10)
            //});
            //Session
            //HttpContext.Session.SetString("myname", firstname);
            //HttpContext.Session.CommitAsync();

            //TempData
            //TempData["myname"] = firstname;
            //TempData.Keep();

            //DI
            //service.SetName(firstname);



            //cache

            //MemoryCacheEntryOptions memoryCacheoptions = new MemoryCacheEntryOptions()
            //{
            //    SlidingExpiration = TimeSpan.FromSeconds(180)
            //};
            //memoryCache.Set("myname",firstname, memoryCacheoptions);

            DistributedCacheEntryOptions distributedOptions = new DistributedCacheEntryOptions
            {
                SlidingExpiration = TimeSpan.FromMinutes(3)
            };
            distributedCache.SetString("myname", firstname, distributedOptions);

            return View();
        }

        public IActionResult About()
        {
            //Cookies
            //ViewData["username"] = Request.Cookies["myname"];
            //Response.Cookies.Delete("myname");

            //Session
            //ViewData["username"] = HttpContext.Session.GetString("myname");
            //HttpContext.Session.Clear();

            //Tempdata
            //var data = TempData.Peek("myname");
            //ViewData["username"] = TempData["myname"];
            //TempData.Keep();

            //DI
            //ViewData["username"]=service.GetName();

            //cache

            //ViewData["username"] = memoryCache.Get<string>("myname");

            //ViewData["username"] = distributedCache.GetString("myname");
            return View();
        }


        [ResponseCache(Duration = 180, VaryByHeader="*")]
        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
