﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StateManagement_DEMO.Services
{
    public class DataService
    {

        private string MyName { get; set; }

        public void SetName(string name)
        {
            this.MyName = name;
        }

        public string GetName()
        {
           return this.MyName;
        }
    }
}
