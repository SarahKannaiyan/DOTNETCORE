﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TagHelperDemo.Models;

namespace TagHelperDemo.Services
{
    public class GalleryService:IGalleryService
    {
        private Dictionary<string, string> imageDict = new Dictionary<string, string>
        {
            {"image one","image1.png" },
            {"image two","image2.png" },
            {"image three", "image3.png"}
        };
        public Dictionary<string, string> GetImages()
        {
            return imageDict;
        }
        public void AddImage(GalleryImage galleryImage)
        {
            imageDict.Add(galleryImage.ImageUrl, galleryImage.Caption);
        }
    }
}
