﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TagHelperDemo.Models
{
    public class GalleryImage
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string ImageUrl { get; set; }

        public string Caption { get; set; }

        public string Description { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime PostedDate { get; set; } 
        
        public string PostedBy { get; set; }
       
    }
}
