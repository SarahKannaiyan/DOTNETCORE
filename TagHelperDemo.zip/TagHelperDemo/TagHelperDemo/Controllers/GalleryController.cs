﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TagHelperDemo.Models;
using TagHelperDemo.Services;

namespace TagHelperDemo.Controllers
{
    public class GalleryController : Controller
    {
        private IGalleryService galleryService;
        public GalleryController(IGalleryService gallerySvc)
        {
            this.galleryService = gallerySvc;
        }
        [HttpGet("getimage", Name = "getimage")]
        public IActionResult GetImage()
        {
            ViewBag.Images = galleryService.GetImages();
            return View();
        }

        [HttpGet("addimage",Name ="addimage")]
        public IActionResult AddImage()
        {
            return View();
        }

        public async Task<IActionResult> AddImage(ImageData imageData, IFormFile file)
        {
            var filepath = $@"{Path.Combine(environment.ContentRootPath, "images")}\{file.FileName}";
            if (file != null && file.Length > 0)
            {
                using (var stream = new FileStream(filepath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
            }
            imageData.FileName = file.FileName;
            galleryService.AddImage(imageData);
            return View();
        }
    }
}