﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace TagHelperDemo.TagHelpers
{
    [HtmlTargetElement("email", TagStructure=TagStructure.NormalOrSelfClosing)]
    public class EmailTagHelper:TagHelper
    {
        public string MailTo { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "a";
            output.Attributes.SetAttribute("href", "mailto:" + MailTo + "@hexaware.com");
            output.Content.SetContent(MailTo);
        }
    }
}
